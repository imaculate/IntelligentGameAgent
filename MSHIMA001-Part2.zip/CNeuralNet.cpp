/*
                                                                           
   (               )                                        )              
 ( )\     )     ( /(       (                  (  (     ) ( /((             
 )((_) ( /(  (  )\())`  )  )(   (  `  )   (   )\))( ( /( )\())\  (   (     
((_)_  )(_)) )\((_)\ /(/( (()\  )\ /(/(   )\ ((_))\ )(_)|_))((_) )\  )\ )  
 | _ )((_)_ ((_) |(_|(_)_\ ((_)((_|(_)_\ ((_) (()(_|(_)_| |_ (_)((_)_(_/(  
 | _ \/ _` / _|| / /| '_ \) '_/ _ \ '_ \/ _` |/ _` |/ _` |  _|| / _ \ ' \)) 
 |___/\__,_\__||_\_\| .__/|_| \___/ .__/\__,_|\__, |\__,_|\__||_\___/_||_|  
                    |_|           |_|         |___/                         

 For more information on back-propagation refer to:
 Chapter 18 of Russel and Norvig (2010).
 Artificial Intelligence - A Modern Approach.
 */

#include "CNeuralNet.h"
#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>
#include "utils.h"


/**
 The constructor of the neural network. This constructor will allocate memory
 for the weights of both input->hidden and hidden->output layers, as well as the input, hidden
 and output layers.
*/
CNeuralNet::CNeuralNet(uint inputLayerSize, uint hiddenLayerSize, uint outputLayerSize, double lRate, double mse_cutoff):inputlayerSize(inputLayerSize), hiddenlayerSize(hiddenLayerSize), outputlayerSize(outputLayerSize), lrate(lRate), e_cutoff(mse_cutoff)
	//you probably want to use an initializer list here
{
	//TODO
	

	initWeights();
	srand(time(NULL));


}
/**
 The destructor of the class. All allocated memory will be released here
*/
CNeuralNet::~CNeuralNet() {
	//TODO
	for (uint32_t i = 0; i < hiddenlayerSize ; ++i) {
		delete[] hiddenLayerWeights[i];
	}

	for (uint32_t i = 0; i < hiddenlayerSize; ++i) {
		delete[] outputLayerWeights[i];
	}
	delete[] outputLayerWeights;
	delete[] hiddenLayerWeights;
	delete[] hiddenLayerOutputs;
	delete[] outputLayerOutputs;
	delete[] _inputs;
	

}
/**
 Method to initialize the both layers of weights to random numbers
*/
void CNeuralNet::initWeights(){
	//TODO
	hiddenLayerWeights = new double*[hiddenlayerSize];
	outputLayerWeights = new double*[outputlayerSize];
	outputLayerOutputs = new double[outputlayerSize];
	hiddenLayerOutputs = new double[hiddenlayerSize];
	_inputs = new double[inputlayerSize];

	for (uint32_t i = 0; i < hiddenlayerSize; ++i) {
		hiddenLayerWeights[i] = new double[inputlayerSize];
		for (uint32_t j = 0; j < inputlayerSize; ++j) {
			hiddenLayerWeights[i][j] = RandomClamped();

		}
	}

	for (uint32_t i = 0; i < outputlayerSize; ++i) {
		outputLayerWeights[i] = new double[hiddenlayerSize];
		for (uint32_t j = 0; j < hiddenlayerSize; ++j) {
			outputLayerWeights[i][j] = RandomClamped();

		}
	}
	
	
}
/**
 This is the forward feeding part of back propagation.
 1. This should take the input and copy the memory (use memcpy / std::copy)
 to the allocated _input array.
 2. Compute the output of at the hidden layer nodes 
 (each _hidden layer node = sigmoid (sum( _weights_h_i * _inputs)) //assume the network is completely connected
 3. Repeat step 2, but this time compute the output at the output layer
*/
void CNeuralNet::feedForward(const double * const inputs) {
	  //TODO

std:copy(inputs , inputs+ inputlayerSize , _inputs);
	for (uint32_t i = 0; i < hiddenlayerSize; ++i) {
		double sum = 0.0;
		for (uint32_t j = 0; j < inputlayerSize; ++j) {
			sum += _inputs[j] * hiddenLayerWeights[i][j];  
		}
		hiddenLayerOutputs[i] = 1 / (1 + exp(-1 * sum));
	
	}

	for (uint32_t i = 0; i < outputlayerSize; ++i) {

		double sum = 0.0;
		for (uint32_t j = 0; j < hiddenlayerSize; ++j) {
			sum += hiddenLayerOutputs[j] * outputLayerWeights[i][j];
		}
		outputLayerOutputs[i] = 1/(1 +exp( -1 * sum));
		
	}
}
/**
 This is the actual back propagation part of the back propagation algorithm
 It should be executed after feeding forward. Given a vector of desired outputs
 we compute the error at the hidden and output layers (allocate some memory for this) and
 assign 'blame' for any error to all the nodes that fed into the current node, based on the
 weight of the connection.
 Steps:
 1. Compute the error at the output layer: sigmoid_d(output) * (difference between expected and computed outputs)
    for each output
 2. Compute the error at the hidden layer: sigmoid_d(hidden) * 
	sum(weights_o_h * difference between expected output and computed output at output layer)
	for each hidden layer node
 3. Adjust the weights from the hidden to the output layer: learning rate * error at the output layer * error at the hidden layer
    for each connection between the hidden and output layers
 4. Adjust the weights from the input to the hidden layer: learning rate * error at the hidden layer * input layer node value
    for each connection between the input and hidden layers
 5. REMEMBER TO FREE ANY ALLOCATED MEMORY WHEN YOU'RE DONE (or use std::vector ;)
*/
void CNeuralNet::propagateErrorBackward(const double * const desiredOutput){
	//TODO
	double * hiddenLayerErrors = new double[hiddenlayerSize];
	double* outputLayerErrors = new double[outputlayerSize];
	for (uint32_t i = 0; i < outputlayerSize; ++i) {
		outputLayerErrors[i] = (desiredOutput[i] - outputLayerOutputs[i])* (1- outputLayerOutputs[i])* outputLayerOutputs[i];
		
	}

	for (uint32_t i = 0; i < hiddenlayerSize; ++i) {
		hiddenLayerErrors[i] = (1 - hiddenLayerOutputs[i]) * hiddenLayerOutputs[i];
		double sum = 0.0;
		for (uint32_t j = 0; j< outputlayerSize; ++j) {
			sum += outputLayerErrors[j] * outputLayerWeights[j][i]; //nnot sure.
		}

		hiddenLayerErrors[i] *= sum;

	}

	for (uint32_t i = 0; i < outputlayerSize; ++i) {
		for (uint32_t j = 0; j < hiddenlayerSize; ++j) {
			outputLayerWeights[i][j] += outputLayerErrors[i]* lrate * hiddenLayerOutputs[j];
		}

	}

	for (uint32_t i = 0; i < hiddenlayerSize; ++i) {
		for (uint32_t j = 0; j < inputlayerSize; ++j) {
			hiddenLayerWeights[i][j] += hiddenLayerErrors[i] * lrate * _inputs[j];
		}

	}
	delete[] hiddenLayerErrors ;
	delete[] outputLayerErrors;
}
/**
This computes the mean squared error
A very handy formula to test numeric output with. You may want to commit this one to memory
*/
double CNeuralNet::meanSquaredError(const double * const desiredOutput){
	/*TODO:
	
	sum <- 0
	for i in 0...outputLayerSize -1 do
		err <- desiredoutput[i] - actualoutput[i]
		sum <- sum + err*err
	return sum / outputLayerSize
	*/
	double sum = 0.0;
	double error = 0.0;
	for (uint32_t j = 0; j< outputlayerSize; ++j) {
		error = desiredOutput[j] - outputLayerOutputs[j];
		sum += error* error;
	}
	return sum/outputlayerSize;
}
/**
This trains the neural network according to the back propagation algorithm.
The primary steps are:
for each training pattern:
  feed forward
  propagate backward
until the MSE becomes suitably small
*/
void CNeuralNet::train(const double** const inputs,
		const double** const outputs, uint trainingSetSize) {
	//TODO
	bool errors = false;

	int index = 0;
	while (!errors) {
		errors = true;
	
		std::cout << "New iteration  "<<index << std::endl;

		for (uint32_t i = 0; i < trainingSetSize; ++i) {
			feedForward(inputs[i]);
			propagateErrorBackward(outputs[i]);
	
			
		}
		double error = 0.0;
		for (uint32_t i = 0; i < trainingSetSize; ++i) {
			feedForward(inputs[i]);
			error = meanSquaredError(outputs[i]);
			if (error > e_cutoff) {

				errors = false;

				std::cout << error << std::endl;

				break;

			}
			
			
		}
		
		index++;
		

	}
}
/**
Once our network is trained we can simply feed it some input though the feed forward
method and take the maximum value as the classification
*/
uint CNeuralNet::classify(const double * const input){
	feedForward(input);
	int max_index = 0;
	double max = 0.0;
	for (uint32_t i = 0; i < outputlayerSize; ++i) {
		if (outputLayerOutputs[i] > max) {
			max = outputLayerOutputs[i];
			max_index = i;
		}
	}
	
	return max_index; //TODO: fix me
}
/**
Gets the output at the specified index
*/
double CNeuralNet::getOutput(uint index) const{
	return outputLayerOutputs[index]; //TODO: fix me
}