/**
(
(     )\ )
( )\   (()/(   (    ) (        (        (  (
)((_)   /(_)) ))\( /( )(   (   )\  (    )\))(
((_)_   (_))  /((_)(_)|()\  )\ |(_) )\ )((_))\
/ _ \  | |  (_))((_)_ ((_)_(_/((_)_(_/( (()(_)
| (_) | | |__/ -_) _` | '_| ' \)) | ' \)) _` |
\__\_\ |____\___\__,_|_| |_||_||_|_||_|\__, |
|___/

Refer to Watkins, Christopher JCH, and Peter Dayan. "Q-learning." Machine learning 8. 3-4 (1992): 279-292
for a detailed discussion on Q Learning
*/
#include "CQLearningController.h"
#include <iostream>    
#include <algorithm>


CQLearningController::CQLearningController(HWND hwndMain) :
	CDiscController(hwndMain),
	_grid_size_x(CParams::WindowWidth / CParams::iGridCellDim + 1),
	_grid_size_y(CParams::WindowHeight / CParams::iGridCellDim + 1)
{
}
/**
The update method should allocate a Q table for each sweeper (this can
be allocated in one shot - use an offset to store the tables one after the other)

You can also use a boost multiarray if you wish
*/
void CQLearningController::InitializeLearningAlgorithm(void)
{
	//setting the prameters for the qTable

	int NumStates = _grid_size_x * _grid_size_y;
	int NumActions = 4;



	//setting the size of the qTable, as well as initializing them to 0

	qTable.resize(NumStates);
	for (int i = 0; i < NumStates; i++)
	{
		qTable[i].resize(NumActions);
		for (int j = 0; j < NumActions; j++)
		{
			qTable[i][j] = 0;
		}
	}


}

//TODO

/**
The immediate reward function. This computes a reward upon achieving the goal state of
collecting all the mines on the field. It may also penalize movement to encourage exploring all directions and
of course for hitting supermines/rocks!
*/
double CQLearningController::R(uint x, uint y, uint sweeper_no)
{
	//return -100 if the sweepers dead and -1 if not
	if (m_vecSweepers[sweeper_no]->isDead())
	{
		return -100;
	}
	else
	{
		return -1; //default


	}
	
}
//TODO: roll your own here!

/**
The update method. Main loop body of our Q Learning implementation
See: Watkins, Christopher JCH, and Peter Dayan. "Q-learning." Machine learning 8. 3-4 (1992): 279-292
*/
bool CQLearningController::Update(void)
{
	//m_vecSweepers is the array of minesweepers
	//everything you need will be m_[something] ;)
	uint cDead = std::count_if(m_vecSweepers.begin(),
		m_vecSweepers.end(),
		[](CDiscMinesweeper * s)->bool {
		return s->isDead();
	});
	double minesCollected = 0;
	vector<vector<int>> PrevPos;
	PrevPos.resize(CParams::iNumSweepers);
	//setting the size for the old positions
	//seeing if we had got all the mines
	for (uint sw = 0; sw < CParams::iNumSweepers; ++sw)
	{
		PrevPos[sw].resize(2);
		minesCollected += m_vecSweepers[sw]->MinesGathered();
	}
	if (minesCollected == CParams::iNumMines)
	{
		std::cout << minesCollected << " " << cDead << endl;
		m_iTicks = CParams::iNumTicks;
	}

	if (cDead == CParams::iNumSweepers) {
		printf("All dead ... skipping to next iteration\n");
		std::cout << minesCollected << " " << cDead << endl;
		m_iTicks = CParams::iNumTicks;
	}
	for (uint sw = 0; sw < CParams::iNumSweepers; ++sw) {
		if (m_vecSweepers[sw]->isDead()) continue;
		/**
		Q-learning algorithm according to:
		Watkins, Christopher JCH, and Peter Dayan. "Q-learning." Machine learning 8. 3-4 (1992): 279-292
		*/
		//getting the posistion
		int x = m_vecSweepers[sw]->Position().x / CParams::iGridCellDim;
		int y = m_vecSweepers[sw]->Position().y / CParams::iGridCellDim;
		ROTATION_DIRECTION act;
		double max = -100000;
		int choice = 0;
		int matches = 1;
		//getting the direction the gets the hights value
		for (int i = 0; i < 4; i++)
		{
			if ((qTable[x * 40 + y][i]) > max)
			{
				max = qTable[x * 40 + y][i];
				choice = i;
				matches = 1;


			}
			else if((qTable[x * 40 + y][i]) == max){
				matches++;

			}
		}
		if (matches == 4) {//if all have the same qvalue, choose randomly to avoid always choosing EAST(0)
			choice = rand() % 4;
		}
		//setting the direction
		switch (choice)
		{
		case 0: act = ROTATION_DIRECTION::EAST;
			break;
		case 1: act = ROTATION_DIRECTION::NORTH;
			break;
		case 2: act = ROTATION_DIRECTION::WEST;
			break;
		case 3: act = ROTATION_DIRECTION::SOUTH;
			break;
		default:
			break;
		}
		//OldMines[sw] = m_vecSweepers[sw]->MinesGathered();
		PrevPos[sw][0] = x;
		PrevPos[sw][1] = y;
		m_vecSweepers[sw]->setRotation(act);

		//1:::Observe the current state:
		//TODO
		//2:::Select action with highest historic return:
		//TODO
		//now call the parents update, so all the sweepers fulfill their chosen action
	}

	CDiscController::Update(); //call the parent's class update. Do not delete this.

	for (uint sw = 0; sw < CParams::iNumSweepers; sw++)

	{
		int x = m_vecSweepers[sw]->Position().x / CParams::iGridCellDim;
		int y = m_vecSweepers[sw]->Position().y / CParams::iGridCellDim;
		//setting the values for the state
		qTable[PrevPos[sw][0] * 40 + PrevPos[sw][1]][m_vecSweepers[sw]->getRotation()] = R(x, y, sw) + dFactor*(max(
			qTable[x * 40 + y][0],
			qTable[x * 40 + y][1],
			qTable[x * 40 + y][2],
			qTable[x * 40 + y][3]));
	}
	if (m_iTicks == CParams::iNumTicks)
	{
		std::cout << minesCollected << " " << cDead << endl;
	}
	return true;
}

CQLearningController::~CQLearningController(void)
{
	//TODO: dealloc stuff here if you need to	
}
